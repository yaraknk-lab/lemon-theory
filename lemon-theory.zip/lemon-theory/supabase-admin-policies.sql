-- Run this in Supabase SQL Editor after the first setup

create policy "Admin can insert articles" on articles
  for insert with check (auth.role() = 'authenticated');

create policy "Admin can update articles" on articles
  for update using (auth.role() = 'authenticated');

create policy "Admin can delete articles" on articles
  for delete using (auth.role() = 'authenticated');

create policy "Admin can update brand" on brand
  for update using (auth.role() = 'authenticated');
