# The Lemon Theory

A minimal editorial digital journal by Yara Al Khateeb.

## Tech Stack
- React + Vite
- Supabase (database + auth)
- Vercel (hosting)

## Deployment

### 1. Push to GitHub
- Create a new repo on github.com
- Upload all these files

### 2. Deploy on Vercel
- Go to vercel.com
- Import your GitHub repo
- Add these environment variables:
  - VITE_SUPABASE_URL
  - VITE_SUPABASE_ANON_KEY

### 3. Admin access
- Go to yoursite.com/admin
- Enter your email
- Supabase sends a magic link
- You're in!
